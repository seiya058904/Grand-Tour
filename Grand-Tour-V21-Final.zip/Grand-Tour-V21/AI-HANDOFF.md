# Grand Tour V21 — AI handoff

## Source of truth

`Grand-Tour-V21.html` is the complete editable application and offline game. There is no build chain. `index.html` redirects to it. The V20 and V19 originals remain byte-for-byte unchanged.

This release was rebuilt from V20 and selectively ports reviewed V21 work. It retains V20's physics, stage data, save schema/key, color palette, Recovery/Threshold button CSS and state behavior. Build markers are `data-build="2100"` and `CONFIG.buildVersion = 210`; save engine/schema remains 9.

## Architecture and boundaries

`Race` owns fixed-step physical state, seeded RNG, AI, groups, timing and snapshots. Read the final effective method before editing. Sprint timing uses playable distance, real speed and burst duration; do not divide reference-route metres by physical speed. TTT merges only when the returning rider is physically ready and uses real queue gaps.

`RaceView`, Canvas rendering, labels and presentation caches are visual only. They must not write physical position, speed, lane, draft, timing, results or RNG. `CyclistRigV21` and damped pose transitions remain presentation state. V20 peloton depth packing and smoothed lane transitions are retained to reduce visual crowd switching. The shared finish lens changes the whole road projection; finisher fade affects only the road layer at the actual finish coordinate.

The power history is presentation-only. Both radio surfaces are intentional: the center popup is short and event filtered; the lower team radio stays visible and more detailed. They update independently. Do not hide one when the other appears. The single Race Centre DOM is moved between desktop and mobile mounts; do not add a duplicate model or DOM ID.

`SaveCodec` intentionally compacts diagnostics. Validate restored physical state and continued trajectories, not raw JSON key order. Do not change the V9 save contract without an explicit migration.

## Verification

Read `V21-REPORT.md`. The authoritative rebuilt evidence is `evidence/rebuild-20260928/`; other V21 evidence directories are from earlier working drafts and are historical only. `tests/static_verify.py --manifest` checks package identity, syntax, assets, DOM IDs, V20 data and hashes.

Cloud browser validation uses exact HTML injection and test-only memory Storage because policy blocks native file navigation. It does not prove native `file://` launch or disk persistence across browser restarts. Mobile hardware, Safari/Firefox, full 21-stage natural play and subjective audio remain unverified.
