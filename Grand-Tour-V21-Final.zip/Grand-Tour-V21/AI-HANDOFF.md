# Grand Tour V21 — AI handoff

## Source of truth

Start from `Grand-Tour-V21.html`. It contains the entire editable application and is also the distributable offline game. There is **no build chain**. `index.html` redirects to it. Do not regenerate it from older patch scripts, bundles or report text. The supplied V20 and V19 HTML files remain byte-for-byte unchanged.

Current identity: **V21**, `data-build="2100"`, `CONFIG.buildVersion = 210`. Save engine/schema remains **9**, with the existing save key. Internal historical helper names (`V18Original`, `DecisionMemoryV20`, etc.) are compatibility/ownership names, not release markers to mass-replace.

## Architectural map

`Race` owns fixed-step physical state, seeded RNG, AI, groups, timing and snapshots. Existing later prototype extensions intentionally override some original methods. Read the final effective method, especially `sprintPower`, `followWheel` and player intent, before editing. `CompactCourse` maps frozen reference route kilometres to playable metres. **Never divide reference metres by a physical m/s speed to estimate time to line.**

`RaceView`, Canvas rendering, labels and presentation caches are visual only. V21's common lens applies uniformly to the road, finish line, markings and every rider. Rider `world` is physical interpolation while racing and actual `x` after finishing. No renderer may write `x`, `renderX`, `v`, `lane`, `drawLane`, draft, timing or results. `CyclistRigV21` and damped pose transitions live in this presentation layer; they must not consume the race RNG or become persisted simulation state.

`SaveCodec` intentionally compacts diagnostic audit arrays. Per-tick controller scratch fields can be rebuilt during restore. Validate equal physical state immediately, then equal future continuation, not raw JSON property order or the presence of discarded diagnostic samples. New tactical state, when necessary, must use the existing validated serialization boundary.

`Ceremony`, `finalizeRace`, classification and next-stage initialization already have settlement guards. Do not bypass them to fake a completed race. The mobile Race Centre reparents the single existing desk; never add a duplicate data model or duplicate element IDs.

## What changed in V21

- State-driven body mechanics, consistent leg lengths, pedal/crank and wheel rotation; smaller bounded body cache.
- Graphite/gold visual system, five-part HUD, actual power history, radio outside the race view; responsive fixes and accessible focus states.
- Honest finish projection and a single smoothly widened finish lens; reduced-motion keeps the lens fixed.
- `finishKickWindow`: actual playable time-to-line gates automatic sprint and reaction timing while retaining burst cost, obstruction and sacrifice guards.
- TTT pace uses the active head's capacity and W′ budget; existing pace control gently closes real wheel gaps. Handoffs avoid unnecessarily overlapping returning riders. Returning riders do not call ordinary reversed-wheel escape until a real merge slot is ready.
- Auto at the front yields modestly at actual local pace rather than an arbitrary low power fraction.

## Boundaries for the next iteration

Retain the 21 supplied stages, physical power/draft/energy, classifications, deterministic seed, saves, cross-stage carry, Auto/designated wheel/teamwork, ITT/TTT, finish/ceremony/results, responsive and reduced-motion behavior. No separate simulation, framework change, invented positions, synthetic overtaking or cosmetic energy/time-gap adjustments.

The route/roster/rule data are the frozen V20 package data. This iteration did not re-verify them against live official websites. Inspect and play actual races; do not mistake passing screenshots or finite-number checks for universally correct tactics.

## Verification

Read `V21-REPORT.md` and `evidence/*.json`. `tests/static_verify.py` checks identity, syntax, remote runtime assets, DOM IDs, history and manifest. Browser tests run the exact canonical HTML rather than copied engine functions. Extra tests exercise follow selection, live animation, seeded TTT comparison and actual Tour settlement/next-stage carry.

The cloud environment forbids native file/network navigation in Chromium. Recorded tests therefore use `--injected`: `about:blank?test`, exact HTML bytes and an explicitly test-only memory Storage adapter. **Native file navigation, real reload/disk persistence, physical mobile performance and Safari/Firefox are Not verified here.** Keep that distinction in future reports.

No Git repository, credentials, local dependencies or source-generation scripts are required for this delivery. `SHA256SUMS.txt` identifies the packaged bytes.

## Terminal actor rendering

`roadActorOpacityV21` retires FINISHED actors from the road over 0.45 simulation seconds (immediately in reduced motion). Their RaceView records and canonical `x` remain intact. Do not restore the V20 fake post-finish extrapolation. Terminal actors must not remain stacked on the finish line; results and ceremony own their presentation after crossing.
