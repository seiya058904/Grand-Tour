# 环法 · Grand Tour V21

一款独立、非官方的公路自行车赛段竞赛游戏。**当前入口：[Grand-Tour-V21.html](Grand-Tour-V21.html)**。

## 开始游玩

解压整个 ZIP，双击 `Grand-Tour-V21.html`，或打开 `index.html`。游戏代码、样式、图标、赛道数据和绘制资源全部包含在单个 HTML 中；游玩不需要 Node.js、Python、安装依赖、运行构建脚本或联网。`index.html` 只负责跳转，不是另一份游戏源码。

桌面使用画面下方的输出档位、Auto、跟轮和补给按钮；Space 进攻／冲刺，D 切换 Auto，F 补给。手机使用同一套触控按钮，右上角「赛况」打开完整赛况中心。减少动态效果遵循浏览器／操作系统设置。

环法模式支持保存、继续和 JSON 导入／导出；**单赛段模式不保存进行中的比赛**。V21 沿用 V20 的 V9 存档结构和存储键。升级前建议在 V20 导出备份；不同浏览器、文件位置或浏览器的本地文件策略可能隔离本地存储，跨位置迁移请使用游戏内导出／导入。

## V21 的主要变化

骑行动作改为连续受力过渡：踏频、起身、摇车、低趴、疲劳和冲刺姿态来自实际功率、速度、坡度和体力。车轮旋转与实际行进距离相连。终点统一镜头变换不改变任何车手的位置或比赛结果；完赛车手由显示层退场进入成绩／领奖，不虚构继续滑行的位置。

HUD 采用石墨色与环法金色，功率／W/kg 合并分层；电台移出比赛画布，避免遮住车群和姓名。移动端优先显示比赛、关键数据和操作，完整 Race Centre 使用同一个可移动面板。

自动终点冲刺按**可骑距离、真实速度和爆发时长**判断时机，避免把参考路线公里数当作物理距离。TTT 修正尚未到位就强制接轮的合流问题，轮换与领骑节奏考虑真实队形、领骑者能力和储备。

完整实现说明、验证证据及限制见 [V21-REPORT.md](V21-REPORT.md)。这些是具体改动，不代表所有种子下的战术都已穷尽验证。

## 继续开发

**`Grand-Tour-V21.html` 本身就是完整、可编辑的源码与可运行成品。没有独立的生成链。** 直接修改它；不要另外维护会覆盖它的构建脚本或第二份模拟引擎。架构边界和兼容性说明见 [AI-HANDOFF.md](AI-HANDOFF.md)。

| 文件 | 用途 |
|---|---|
| `Grand-Tour-V21.html` | 当前完整源码／离线游戏 |
| `index.html` | 默认入口，跳转 V21 |
| `V21-REPORT.md` | 本轮改动、实测和未验证范围 |
| `Grand-Tour-V20.html`、`V20-REPORT.md` | 附件中的原版 V20，原样保留 |
| `previous-version/` | 原版 V19，以及 V20 的原 README／交接说明／旧校验单 |
| `tests/` | 可复跑的包检查和 Chromium 浏览器测试；不是运行依赖 |
| `evidence/` | 本轮最终验证摘要与少量实际运行截图 |
| `SHA256SUMS.txt` | 当前交付文件的 SHA-256 清单 |

附件没有提供 V12、V18.3.1、Git 历史或原开发机目录，本包也不假称包含它们。未选择开源许可证；沿用原项目声明。本作品不隶属于环法组织方、车队或车手。

## 可选验证

```sh
python tests/static_verify.py --manifest
python -m pip install -r tests/requirements.txt
python -m playwright install chromium
python tests/browser_verify.py --out /tmp/grand-tour-v21-qa
python tests/extended_verify.py --out /tmp/grand-tour-v21-extended
```

浏览器测试默认使用真正的 `file://` 打开方式。若执行环境策略禁止文件导航，可加 `--injected`：它把原 HTML 原样注入 Chromium，并使用**仅供测试的内存 Storage**。这能验证代码、Canvas、UI、序列化与恢复，但不能证明本地文件打开或磁盘存储在该环境中可用。测试没有往成品注入这套替代存储。
