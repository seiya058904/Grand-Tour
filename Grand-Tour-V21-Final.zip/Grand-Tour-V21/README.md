# 环法 · Grand Tour V21

一款独立、非官方的公路自行车赛段竞赛游戏。**当前入口：[Grand-Tour-V21.html](Grand-Tour-V21.html)**。

## 开始游玩

解压整个 ZIP，双击 `Grand-Tour-V21.html`，或打开 `index.html`。游戏代码、样式、图标、赛道数据和绘制资源都在单个 HTML 中；无需安装运行环境、构建或联网。

桌面使用画面下方的输出档位、Auto、跟轮和补给按钮；Space 进攻／冲刺，D 切换 Auto，F 补给。手机使用同一套触控按钮，点右上角“赛况”打开完整 Race Centre。减少动态效果遵循系统设置。

本版以原始 V20 源码为基线，挑选移植 V21 的战术、骑行动作与功率信息改进。V20 的颜色、恢复耐力／阈值按钮行为、赛段物理和存档结构保留。比赛画布中央有低频精简电台，画布下方另有持续更新的详细电台。

环法模式支持保存、继续和 JSON 导入／导出；单赛段模式不保存进行中的比赛。V21 沿用 V20 的 V9 存档结构与存储键。不同浏览器或文件位置的本地存储可能隔离，跨位置迁移请使用游戏内导出／导入。

完整改动、对照结果、复跑方法及未验证范围见 [V21-REPORT.md](V21-REPORT.md)。

## 文件

| 文件 | 用途 |
|---|---|
| `Grand-Tour-V21.html` | 当前完整源码／离线游戏 |
| `index.html` | 默认入口，跳转 V21 |
| `V21-REPORT.md` | 本次 V20 基线重建和验证报告 |
| `Grand-Tour-V20.html`、`V20-REPORT.md` | 原版 V20 |
| `previous-version/` | 原版 V19 及旧版本文档 |
| V21 Final ZIP 内的 `tests/` 与 `evidence/` | 可复跑检查、实际运行证据 |
| ZIP 内 `SHA256SUMS.txt` | 包内交付文件校验清单 |

## 可选验证

```sh
python tests/static_verify.py --manifest
python -m pip install -r tests/requirements.txt
python -m playwright install chromium
python tests/browser_verify.py --out /tmp/grand-tour-v21-qa
python tests/radio_overlay_verify.py --source Grand-Tour-V21.html --out /tmp/grand-tour-v21-radio-qa
python tests/extended_verify.py --out /tmp/grand-tour-v21-extended
```

浏览器测试默认用 `file://`。若执行环境禁止原生文件导航，可加 `--injected`；测试会载入原 HTML 字节并使用仅限测试的内存 Storage。该模式能验证游戏逻辑、Canvas、界面及序列化，但不能验证本地文件导航或磁盘持久性。

## 关于

本项目为独立、非官方作品，与环法组织方、车队或参赛车手无隶属或背书关系。项目尚未选择开源许可证。
