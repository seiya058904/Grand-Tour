# Verification evidence

`rebuild-20260928/` is authoritative for the V20-based V21 source hash recorded in each JSON file and in `V21-REPORT.md`. It includes the all-stage and four-race fixed-step run, TTT and sprint comparisons, effort-button comparison, peloton frame-order sampling and screenshots. Supplemental radio overlay evidence is in `radio-rebuild-20260928/`.

The other directories at this level contain evidence from earlier V21 working drafts. They are retained for history, not for validating the current V20-based rebuild. Do not combine those old hashes or results with the current report.

Browser checks used Chromium and the exact HTML source with a test-only in-memory Storage adapter. They do not certify native file navigation or disk persistence after a full browser restart.
