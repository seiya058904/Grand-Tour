# V21 verification evidence

All V21 result JSON files name the exact canonical HTML SHA-256. The V20 baseline and comparisons are explicitly labelled. Tests ran in Chromium with an exact HTML injection plus a test-only memory Storage adapter because managed browser policy blocked native file and HTTP navigation. No native file/persistent-origin guarantee is implied.

`main/verification.json`: all-stage starts, deterministic restore, physical runs, UI, storage serialization and responsive checks. The four `*-physical.json` files retain the actual crossing/audit samples. Screenshot replay states came from those engine runs; only the unsupported single-stage save mode was adapted to the supported tour snapshot decoder. No rider positions, energy or results were edited for these screenshots.

`extended/extended-verification.json`: real input actions, TTT seeded queue comparison, a Tour stage-to-stage transition, natural rain and narrow viewports.

`finish/finish-verification.json`: naturally reached last metres, real sprint control, exact finished positions, display retirement and real ceremony controls.

`downhill/downhill-verification.json`: naturally reached >6% descent and corresponding pose.

`performance.json`: a short shared-cloud live probe, not a physical device/FPS promise. `light` is the monitor state, while `effectiveLow` is the actual quality decision.

`flat-sprint-comparison.json`: original V20 and final V21 crossing samples, not intermediate development builds. This is one-seed evidence, not an exhaustive balance result.

Tests reproduce their own temporary output outside the project by default. Development patch scripts and temporary replay snapshots are not production dependencies and are not shipped.
