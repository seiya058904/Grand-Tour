# Grand Tour V20 — AI handoff

## Start here

`Grand-Tour-V20.html` is the canonical current game and the file to inspect first. It is a complete, self-contained offline browser game. Open it directly to play; there is no build step, dependency installation, or external runtime. `index.html` is the repository-style redirect entry point and opens `Grand-Tour-V20.html`.

The included `previous-version/Grand-Tour-V19.html` and its report are for focused comparison with the immediate predecessor. They are historical references; make any next iteration from V20 and preserve both existing version files.

## Package contents

- `Grand-Tour-V20.html` — current playable source of truth.
- `index.html` — current-version redirect.
- `README.md` and `V20-REPORT.md` — project and current release context.
- `previous-version/Grand-Tour-V19.html` and `previous-version/V19-REPORT.md` — immediate predecessor and its history.
- `SHA256SUMS.txt` — checksums for the source files in this package.

Older V12 and V18.3.1 artifacts, local-only history/evidence folders, Git internals, generated output, and local environment files are not included. The V19 report may refer to a comparison page on the original developer machine; that local-only page is not part of this package.

## Iteration guidance

First inspect the current game and reproduce a concrete issue or define a specific requested improvement. Keep the change focused and retain the single-file, offline delivery format. Avoid broad rewrites or unrelated features.

Treat stage routes and profiles, race physics and timing, rankings/classifications, deterministic behavior, save compatibility, sprint/winner locks, team support, pacelines, time-trial/team-time-trial behavior, controls, and the established Race Centre and ceremony flows as mature systems. Preserve them unless the requested change requires an adjustment or a reproducible defect demonstrates one is necessary. Compare V20 with V19 when that helps isolate presentation changes from race-system behavior.

After a change, report the exact files changed and the checks actually performed. The V20 report records prior offline Chromium and simulation checks, but it does not claim a complete continuous 21-stage tour or acceptance on a physical phone/Safari. Do not present those as verified for a new iteration without performing them.

## Current artifact identity

- Version: V20, release date 2026-09-27.
- Expected byte size: 1738562.
- Expected SHA-256: `3d7d013d61c6d01459a8d3185fb4ff2b30983a4a172245190d858311325e2581`.
- Expected HTML release marker: `data-build="2000"`.