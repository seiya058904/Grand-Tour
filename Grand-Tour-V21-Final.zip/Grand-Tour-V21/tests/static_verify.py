#!/usr/bin/env python3
"""Dependency-free package checks; Node.js adds syntax verification if present."""
from __future__ import annotations
import argparse, collections, hashlib, json, re, shutil, subprocess, tempfile
from html.parser import HTMLParser
from pathlib import Path
import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]

class Inventory(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.remote_assets=[]; self.scripts=[]; self.in_script=False
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.append(a['id'])
        if tag=='script': self.in_script=True; self.scripts.append('')
        keys=['src'] if tag in ('script','img','audio','video','source','iframe') else ['href'] if tag=='link' and a.get('rel')=='stylesheet' else []
        for key in keys:
            if re.match(r'^(https?:)?//',a.get(key,'')): self.remote_assets.append(a[key])
    def handle_endtag(self, tag):
        if tag=='script': self.in_script=False
    def handle_data(self, data):
        if self.in_script:self.scripts[-1]+=data

def main(args):
    src=ROOT/'Grand-Tour-V21.html'; text=src.read_text(encoding='utf-8'); baseline=(ROOT/'Grand-Tour-V20.html').read_text(encoding='utf-8')
    p=Inventory();p.feed(text); duplicates=[k for k,n in collections.Counter(p.ids).items() if n>1]
    facts={
      'canonical_html_exists':src.is_file(),
      'release_marker':'data-build="2100"' in text,
      'runtime_build':bool(re.search(r'buildVersion\s*:\s*210\b',text)),
      'title':bool(re.search(r'<title>[^<]*V21[^<]*</title>',text)),
      'entry':'Grand-Tour-V21.html' in (ROOT/'index.html').read_text(encoding='utf-8') and 'Grand-Tour-V20.html' not in (ROOT/'index.html').read_text(encoding='utf-8'),
      'unique_dom_ids':not duplicates,
      'no_remote_runtime_assets':not p.remote_assets,
      'v20_unmodified':hashlib.sha256((ROOT/'Grand-Tour-V20.html').read_bytes()).hexdigest()=='3d7d013d61c6d01459a8d3185fb4ff2b30983a4a172245190d858311325e2581',
      'history_present':(ROOT/'previous-version/Grand-Tour-V19.html').is_file(),
      'documentation':all((ROOT/f).is_file() for f in ['README.md','AI-HANDOFF.md','V21-REPORT.md']),
      'frozen_stage_data':all(line in text for line in baseline.splitlines() if line.startswith(('const OFFICIAL_PROFILE_DATA_V182=','const V181_STAGE_DATA=','const STAGE_DATA='))),
      'save_schema_retained':'this.engineVersion=9' in text and "version:9," in text,
    }
    syntax='Not verified: Node.js not installed'
    if shutil.which('node'):
        with tempfile.TemporaryDirectory(prefix='grand-tour-syntax-') as td:
            for i,script in enumerate(p.scripts):
                path=Path(td)/f'inline-{i}.js';path.write_text(script, encoding='utf-8')
                result=subprocess.run(['node','--check',str(path)],capture_output=True,text=True)
                if result.returncode: raise AssertionError(result.stderr)
        syntax='PASS';facts['javascript_syntax']=True
    manifest=ROOT/'SHA256SUMS.txt'
    if args.manifest:
        assert manifest.exists(), 'Missing manifest'
        for line in manifest.read_text(encoding='utf-8').splitlines():
            digest,name=line.split('  ',1)
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest, 'Hash mismatch: '+name
        facts['manifest']=True
    report={'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'checks':facts,'duplicate_ids':duplicates,'remote_runtime_assets':p.remote_assets,'syntax':syntax,'pass':all(facts.values())}
    print(json.dumps(report,ensure_ascii=False,indent=2))
    if not report['pass']:raise SystemExit(1)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--manifest',action='store_true');main(parser.parse_args())
